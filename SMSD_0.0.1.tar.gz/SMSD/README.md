# SMSD
Sequential Methods for Study Design
